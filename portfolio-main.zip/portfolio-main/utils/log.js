export const displayFancyLogs = () => {
  console.log(
    "%c  ____  _           _     _       ____                          _\n / ___|| |__  _   _| |__ | |__   |  _ \\ ___  _ ____      ____ _| |\n \\___ \\| '_ \\| | | | '_ \\| '_ \\  | |_) / _ \\| '__\\ \\ /\\ / / _` | |\n  ___) | | | | |_| | |_) | | | | |  __/ (_) | |   \\ V  V / (_| | |\n |____/|_| |_|\\__,_|_.__/|_| |_| |_|   \\___/|_|    \\_/\\_/ \\__,_|_|\n",
    "background: #212121; color: #6b17e8;"
  );

  console.log(
    "%c Hope you like what you see :)",
    "background: #212121; color: #6b17e8; padding: 6px;"
  );
};
