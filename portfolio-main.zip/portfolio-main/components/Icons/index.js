export { default as IconMail} from "./mail";
export { default as IconGithub} from "./github";
export { default as IconLinkedin} from "./linkedin";
export { default as IconInstagram} from "./instagram";
export { default as IconTwitter} from "./twitter";
export { default as IconExternal} from "./external";
export { default as IconDocument} from "./document";
export { default as Icon } from './icon';
